- Compatible with updated version of php

- Only Required for Elementor

- Fix export setting of revslider